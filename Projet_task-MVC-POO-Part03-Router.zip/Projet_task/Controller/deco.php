<?php
//Destruction de la session
session_destroy();

//Redirection HTTP
header('location:/projet_php/Projet_task/accueil');

?>